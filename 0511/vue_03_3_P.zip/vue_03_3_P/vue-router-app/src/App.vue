<template>
  <div id="app">
    <nav>
      <h1>진화 단계 가이드</h1>

     
    
      <router-link to="/" tag="button">Home</router-link>
      <router-link to="/happeed" tag="button">Start</router-link>
      
     
    </nav>
    <router-view/>
  </div>
</template>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}

nav {
  padding: 30px;
}

button {
  background-color: white;

  line-height: 4;
  width: 100px;
  
  border-color: #F1A324;
  justify-content: space-evenly;
  
  margin-right: 30px;
  
  
}

button :hover {
  background-color: #F7E43A;
}

nav a.router-link-exact-active {
  color: #42b983;
}
</style>
