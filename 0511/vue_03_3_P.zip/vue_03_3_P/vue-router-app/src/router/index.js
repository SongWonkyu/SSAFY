import Vue from 'vue'
import VueRouter from 'vue-router'
import HomeView from '../views/HomeView.vue'

import NotFound from '../views/NotFound.vue'
import Ssafling from '../views/Ssafling.vue'
import Ssafleaf from '../views/Ssafleaf.vue'
import Ssaflower from '../views/Ssaflower.vue'
import Nocolor from '../views/Nocolor.vue'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'home',
    component: HomeView
  },
  {
    path: '/notfound',
    name: 'notfound',
    component: NotFound
  },
  {
    path: '/happeed',
    name: 'happeed',
    component: Nocolor
  },
  {
    path: '/happling',
    name: 'happling',
    component: Ssafling
  },
  {
    path: '/happlossome',
    name: 'happlossome',
    component: Ssafleaf
  },
  {
    path: '/happlower',
    name: 'happlower',
    component: Ssaflower
  },
  
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
