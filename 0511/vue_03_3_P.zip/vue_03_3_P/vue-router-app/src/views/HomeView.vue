<template>
  <div class="home">

    <h2>Start 버튼으로 시작해 보세요!</h2>      
    <img alt="Vue logo" src="../assets/ssafy-banner.png">
    
  </div>
</template>

<script>
// @ is an alias to /src


export default {
  name: 'HomeView',
  
}
</script>
