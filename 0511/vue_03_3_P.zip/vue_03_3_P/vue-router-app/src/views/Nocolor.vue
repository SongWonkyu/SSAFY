<template>
  <div>
    
     
     <div class="container">

      <h2>시작</h2>
      <div class="container2">

       <router-link to="/"><i class="fa-solid fa-circle-chevron-left fa-2x"></i></router-link>

        <img alt="Vue logo" src="../assets/happeed.png">
        <router-link to="/happling"><i class="fa-solid fa-circle-chevron-right fa-2x"></i></router-link>
        

      </div>
      
    <h2>해피드</h2>
     </div>

  </div>
</template>

<script>
export default {

}
</script>

<style>
img {
  width: 400px;
  height: 400px;
}

i {
  justify-content: center;
  align-items: center;

  
}
.container {
  display: flex;
  flex-direction: column;
  box-shadow: rgba(50, 50, 93, 0.25) 0px 6px 12px -2px, rgba(0, 0, 0, 0.3) 0px 3px 7px -3px;
}

.container2 {
  display: flex;
  justify-content: center;
  align-items: center;
}
</style>