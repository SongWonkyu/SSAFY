<template>
  <div>
  <h1>찾으시려는 페이지가 존재하지 않습니다!</h1>
  <img alt="Vue logo" src="../assets/noResult.png">

  </div>
</template>