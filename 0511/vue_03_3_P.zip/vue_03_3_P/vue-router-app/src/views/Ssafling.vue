<template>
  <div class="container">

      <h2>1단계</h2>
      <div class="container2">

        <i class="fa-solid fa-circle-chevron-left fa-2x" @click="before"></i>
        <img alt="Vue logo" src="../assets/happling.png">
        <router-link to="/happlossome"><i class="fa-solid fa-circle-chevron-right fa-2x"></i></router-link>

      </div>
      
    <h2>해플링</h2>
    </div>
</template>

<script>
export default {
  name: 'Ssafling',
  methods:{
  before() {
    alert('이전 진화 단계로 돌아갈 수 없습니다.')
  }
  }
}
</script>

<style>

</style>