<template>
    <div class="container">

      <h2>3단계</h2>
      <div class="container2">

        <router-link to="/happlossome"><i class="fa-solid fa-circle-chevron-left fa-2x" @click="before"></i></router-link>
        <img alt="Vue logo" src="../assets/happlower.png">
        <router-link to="/"><i class="fa-solid fa-circle-chevron-right fa-2x" @click = "toHome"></i></router-link>

      </div>
      
    <h2>해플라워</h2>
    </div>
</template>

<script>
export default {
  name: 'Ssaflower',
  methods:{
  before() {
    alert('이전 진화 단계로 돌아갈 수 없습니다.')
  },
  toHome() {
    alert('Home으로 돌아갑니다!')
  }
  }
}
</script>

<style>

</style>