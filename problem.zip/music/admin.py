from django.contrib import admin
from .models import Music, Review
# Register your models here.

admin.site.register(Music)
admin.site.register(Review)