from rest_framework.response import Response
from rest_framework.decorators import api_view
from rest_framework import status

from django.shortcuts import get_object_or_404, get_list_or_404

from .serializers import MusicListSerializer, MusicSerializer, MusicReviewCntSerializer, ReviewSerializer
from .models import Music, Review


@api_view(['GET', 'POST'])
def music_list(request):
    if request.method == 'GET':
        music_all = Music.objects.all()
        serializer = MusicListSerializer(music_all, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)
    
    # 문제 2. MusicSerializer를 이용하여 유효성 검사 후 음악 정보를 생성할 수 있도록 코드를 완성하시오.
    elif request.method == 'POST':
        serializer = MusicSerializer(data=request.data)
        if serializer.is_valid(raise_exception=True): # is_valid를 활용하여 유효성 검사를 실시한다.
            serializer.save() # 유효성 검사를 통과하면 저장한다.
            
            return Response(serializer.data)


@api_view(['GET', 'DELETE', 'PUT'])
def music_detail(request, music_pk):
    # 문제 3. 찾으려는 데이터가 없으면 404 상태 코드를 반환할 수 있도록 아래 코드를 완성하시오.
    music = get_object_or_404(Music, pk=music_pk) # get_object_404를 사용하여 음악 클래스를 저장한다
    if request.method == 'GET':
        serializer = MusicReviewCntSerializer(music)
        return Response(serializer.data)
    
    # 문제 4. 음악 데이터를 삭제하고 {'delete': 삭제되는음악pk} 형태의 JSON으로 반환하도록 코드를 완성하시오.
    elif request.method == 'DELETE':
        music.delete()
        result = {'delete':music_pk}
        return Response(result, status=status.HTTP_204_NO_CONTENT)   # key에 delete를 value에 music_pk가 나오도록 응답한다
    # 문제 5. 음악 데이터를 수정할 수 있도록 아래 코드를 완성하시오.
    # 수정이 정상적으로 완료되었다면 수정된 데이터를 JSON 형태로 반환합니다.
    elif request.method == 'PUT':
        serializer = MusicSerializer(music,data=request.data) # 기존의 뮤직 인스턴스에 수정을 한다.
        if serializer.is_valid(raise_exception=True): # is_valid를 활용하여 유효성 검사를 실시한다.
            serializer.save() # 유효성 검사를 통과하면 저장한다.
            
            return Response(serializer.data)


# 문제 7. 모든 리뷰 정보를 반환하도록 review_list 코드를 완성하시오.
@api_view(['GET'])
def review_list(request):
    if request.method == 'GET':
        review_all = Review.objects.all() # review_all에 리뷰의 모든 정보를 담는다.
        serializer = ReviewSerializer(review_all, many= True) # many=True 값을 지정하여 리스트를 받는 시리얼라이저를 활용한다.
        return Response(serializer.data, status=status.HTTP_200_OK) # 시리얼라이저의 데이터를 응답한다.


# 문제 8. 리뷰를 생성할 수 있도록 아래 코드를 완성하시오.
# 유효성 검사를 통과하지 못하면 정보와 400 상태코드를 반환합니다.
# 작성된 리뷰의 JSON과 함께 201 상태 코드를 반환합니다.
@api_view(['POST'])
def review_create(request, music_pk):
    music = get_object_or_404(Music, pk=music_pk) # 한 개의 뮤직에 리뷰를 작성하는 것이므로 일단 한 개의 뮤직을 가져온다
    if request.method == 'POST':
       serializer = ReviewSerializer(data=request.data) # 시리얼라이저의 입력 데이터를 받습니다.
       if serializer.is_valid(raise_exception=True): # raise_exception을 활용해 유효성 정보를 통과하지 못하면 400코드를 응답합니다.
           serializer.save(music=music) # 저장할 때 외부키를 지정한 상태이므로 외부키또한 같이 저장해줍니다.
           return Response(serializer.data, status=status.HTTP_201_CREATED) #201응답 코드도 같이 반환합니다.



@api_view(['GET', 'DELETE'])
def review_detail(request, review_pk):
    # 문제 9. 리뷰 정보를 조회할 수 있도록 아래 코드를 완성하시오.
    # 찾는 리뷰가 없으면 404 상태 코드를 반환합니다.
     
    if request.method == 'GET':
        review = get_object_or_404(Review, pk=review_pk) # 찾는 리뷰가 없으면 404 코드를 응답
        serializer = ReviewSerializer(review)
        return Response(serializer.data) # 시리얼라이저 데이터를 응답
    
    # 문제 10. DELETE 로 요청오는 경우 해당 리뷰가 삭제될 수 있도록 아래에 코드를 완성하시오.
    # 삭제하려는 리뷰가 없으면 404 상태 코드를 반환합니다.
    # 삭제가 정상적으로 완료되면 {'delete': 삭제된리뷰PK} 형태인 JSON이 204 상태코드와 함께 반환됩니다.
    elif request.method == 'DELETE':
        review = get_object_or_404(Review, pk=review_pk) # 찾는 리뷰가 없으면 404 코드를 응답
        review.delete() # 리뷰를 삭제한다.
        result = {'delete': review_pk}
        return Response(result, status=status.HTTP_204_NO_CONTENT) # {'delete': 삭제된리뷰PK}와 204 상태코드를 응답한다.
